#!/bin/bash

# check_users: currently loggin users.
# check_load
# check_disk
# check_procs: 
# check_mem: physical memory percentage
# check_swap: swap consumed percentage
# cpu_usage

log_file=/home/pranshu/out_$(basename $0)_$(date +%d_%b).log

exec &>> ${log_file}

echo -e "\n Date and time when the script is running."
date

echo -e "\n Hostname, OS version, CPU architecture, and kernel version."
hostnamectl

echo -e "\n NICs breifing."
ip -4 -br addr show

echo -e "\n Kernel routing table."
ip route show

echo -e "\n Number of CPU(s), Socket(s), and Core(s) per socket."
lscpu | grep -E '^CPU\(s\)|Socket|Core\(s\)'

# Total nonIdleTime-idleTime
echo -e "\n CPU percentage."
cpu_usage() {
first_reading=$(grep -w "^cpu" /proc/stat)
sleep 1
second_reading=$(grep -w "^cpu" /proc/stat)

read -r -a first_values <<< "$first_reading"
read -r -a second_values <<< "$second_reading"

total_time=0; total_idle=0; total_non_idle=0

for ((i = 1, j = 1; i < ${#first_values[@]}, j < ${#second_values[@]}; i++, j++))
do
    total_time=$((total_time + second_values[j] - first_values[i]))
    if [[ $i -eq 4 || $j -eq 4 || $i -eq 5  || $j -eq 5 ]]; then
        total_idle=$((total_idle + second_values[j] - first_values[i]))
    fi
done

total_non_idle=$((total_time - total_idle))

cpu_usage=$(awk "BEGIN {printf \"%.2f\", ($total_non_idle / $total_time) * 100}")

echo "$cpu_usage"
}

cpu_usage

echo -e "\n Memory usage."
free -hw

printf "\n%s" " Memory percentage: "
total=0
for (( i=0; i<5; i++ ))
do
    mem_usage=$(free | awk '/Mem/ {printf "%.2f\n", $3/$2 * 100.0}')
    total=$(awk "BEGIN {print $total + $mem_usage}")
    sleep 1
done

average=$(awk "BEGIN {printf \"%.2f\", $total / 5}")
printf "%s\n" "$average%"

printf "\n%s" " Swap percentage: "
total=0
for (( i=0; i<5; i++ ))
do
    swap_usage=$(free | awk '/Swap/ {printf "%.2f\n", $3/$2 * 100.0}')
    total=$(awk "BEGIN {print $total + $swap_usage}")
    sleep 1
done

average=$(awk "BEGIN {printf \"%.2f\", $total / 5}")
printf "%s\n" "$average%"

echo -e "\n Currently logged in users."
w

export PS_FORMAT="ruser,pid,ppid,nice,wchan:25,pmem,pcpu,time:15,euser,stat,flags,stime,thcount,comm:25"
echo -e "\n Top CPU consuming processes."
ps -e --sort=-pcpu | grep -v grep | head

echo -e "\n Top Memory consuming processes."
ps -e --sort=-pmem | grep -v grep | head

echo -e "\n Processes running other than root."
ps -e | grep -v ^root

echo -e "\n Any zombie processes."
ps -e | grep Z | grep -v grep

echo -e "\n I/O utilization."
vmstat -aw 2 5 | sed '3d'

echo -e "\n Uptime and load average."
uptime

echo -e "\n Today reboots"
last reboot -s today | head -15

echo -e "\n Today failed logins."
sudo lastb -s today | head -15

echo -e "\n Today logins."
sudo last -s today | head -15

echo -e "\n Mount points, inodes with their file system and total storage."
export FIELD_LIST=source,fstype,itotal,iused,iavail,ipcent,size,used,avail,pcent,file,target
df -h --output=$FIELD_LIST --total

echo -e "\n Physical volumes"
sudo pvdisplay

echo -e "\n Volumes groups and physical volumes in a group."
sudo vgdisplay

echo -e "\n Logical volumes on a volume group."
sudo lvdisplay

echo -e "\n Failed units."
systemctl list-units --state=failed --all | cat

echo -e "\n Sockets that are listening."
sudo ss -lntup

echo -e "\nNo. of established connection of processes."
sudo ss -Hntup state established | cut -d '"' -f 2 |  sort | uniq -c | sort -nr | column -t -N EstabCount,Process

echo -e "\n Data packets statistics."
ip -stat addr

echo -e "\n Warnings"
journalctl -r -S today -p err | head -20

echo -e "\n Alerts"
journalctl -r -S today -p alert | head -20